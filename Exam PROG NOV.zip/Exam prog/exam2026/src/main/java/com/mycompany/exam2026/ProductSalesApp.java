// Question 1//
import java.util.Scanner;

// ========== INTERFACE ==========
interface IProduct {
    int GetTotalProductsSold();
    double GetAverageProductSold();
    String GetMostPopularProduct();
}

// ========== PRODUCT CLASS ==========
class Product implements IProduct {
    private final int[][] sales;
    private final String[] productNames;

    public Product(int[][] sales, String[] productNames) {
        this.sales = sales;
        this.productNames = productNames;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int[] sale : sales) {
            for (int j = 0; j < sale.length; j++) {
                total += sale[j];
            }
        }
        return total;
    }

    @Override
    public double GetAverageProductSold() {
        int total = GetTotalProductsSold();
        int count = sales.length * sales[0].length;
        return (double) total / count;
    }

    @Override
    public String GetMostPopularProduct() {
        int max = sales[0][0];
        int maxIndex = 0;
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                if (sales[i][j] > max) {
                    max = sales[i][j];
                    maxIndex = i;
                }
            }
        }
        return productNames[maxIndex] + "(" + max + ")";
    }
}

// ========== PRINT CLASS ==========
class PrintProduct {
    private final Product product;

    public PrintProduct(Product product) {
        this.product = product;
    }

    public void PrintTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void PrintAverageProductSales() {
        System.out.println("AVERAGE PRODUCT SALES: " + (int) product.GetAverageProductSold());
    }

    public void PrintMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}

// ========== MAIN CLASS ==========
public class ProductSalesApp {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            String[] productNames = {
                "Cozy Nights Monarch",
                "Restonic Barbados",
                "Sealy Phuket"
            };
            
            int[][] sales = new int[3][3];
            
            for (int i = 0; i < productNames.length; i++) {
                for (int j = 0; j < 3; j++) {
                    System.out.print("Enter number of sales for month " + (j + 1) + " for " + productNames[i] + " mattress: ");
                    sales[i][j] = scanner.nextInt();
                }
                System.out.println();
            }
            
            Product product = new Product(sales, productNames);
            PrintProduct print = new PrintProduct(product);
            
            System.out.println("PRODUCT SALES REPORT - 2026");
            System.out.println();
            System.out.println("******************************************");
            System.out.println();
            print.PrintTotalProductSales();
            print.PrintAverageProductSales();
            print.PrintMostPopularProduct();
        }
    }
}